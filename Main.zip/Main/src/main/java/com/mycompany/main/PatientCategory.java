/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author Student
 */
/**
 * The three categories a patient can be registered under.
 * Using an enum means the value can never be anything invalid -
 * the compiler enforces it, so no string-validation method is needed
 * for category the way we needed one for ID and age.
 */
public enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY
}
